import java.util.Scanner;

public class CaptureGradeStatistics {

	public static void main(String[] args) {
		//Initialize variables and scanner
		Scanner scanner = new Scanner(System.in);
		double classGrades = 0;
		double gradesTotal = 0;
		double gradesMinimum= 0;
		double gradesMaximum = 0;
		double gradesAverage = 0;
		int gradeAmount = 10;
		String ordinal = "default";
		
		//Collect grade input loop
		for (int i = 0; i < gradeAmount; i++)		{	
		//Select the ordinal for each number to display
		switch (i)	{
			case 0:
				ordinal = "st";
				break;
			case 1:
				ordinal = "nd";
				break;
			case 2:
				ordinal = "rd";
				break;
			//4-10 all end in th
			case 3:
			case 4: 
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
				ordinal = "th";
				break;
		}
		//Ask for user input (grades)
		System.out.println("Please enter the " + (i + 1) + ordinal + " grade");
			//Store input
			classGrades = scanner.nextDouble();
		//set first min/max
		if (i == 0)	{
				gradesMaximum = classGrades;
				gradesMinimum = classGrades;
			}
			
			//Make sure comparisons only happen after first loop
		if (i > 0)	{
			//Compare the numbers to find maximum
			if (classGrades > gradesMaximum)	{
				gradesMaximum = classGrades;
			}
			//Compare the numbers to find the minimum
			if (classGrades < gradesMinimum)	{
				gradesMinimum = classGrades;
			}
			
		}
			//add to total
			gradesTotal = gradesTotal + classGrades;
			
		}   //End of grade input loop
		
		//Calculate the average
		gradesAverage = gradesTotal/gradeAmount;
		
		//Print all information
		System.out.println("Average: " + gradesAverage);
		System.out.println("Minimum: " + gradesMinimum);
		System.out.println("Maximum: " + gradesMaximum);
		
	}
}
