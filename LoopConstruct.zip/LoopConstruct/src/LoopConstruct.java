import java.util.Scanner;
public class LoopConstruct {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		double userNum1 = 0;
		double userNum2 = 0;
		double userNum3 = 0;
		double userNum4 = 0;
		double userNum5 = 0;
		int userInputs = 1;
		System.out.println("Five numbers are required to calculate the Total, Average, Maximum, Minimum, and the Interest");
		//Ask for user inputs,use the amount of user inputs to stop the loop
		while (userInputs < 6)	{
			//Ask for user inputs, use the amount of user inputs and a switch to print out the correct message (1st,2nd,3rd,4th,5th) number, and then record the correct number
			switch (userInputs)	{
				case 1:
					System.out.println("Please enter the 1st number");
					userNum1 = scanner.nextDouble();
					userInputs = userInputs + 1;
					break;
				case 2:
					System.out.println("Please enter the 2nd number");
					userNum2 = scanner.nextDouble();
					userInputs = userInputs + 1;
					break;
				case 3:
					System.out.println("Please enter the 3rd number");
					userNum3 = scanner.nextDouble();
					userInputs = userInputs + 1;
					break;
				case 4:
					System.out.println("Please enter the 4th number");
					userNum4 = scanner.nextDouble();
					userInputs = userInputs + 1;
					break;
				case 5:
					System.out.println("Please enter the 5th number");
					userNum5 = scanner.nextDouble();
					userInputs = userInputs + 1;
					break;
					
			}
		
			
				
		}
		
		//after getting all values, let the user know it was successful
		System.out.println("All inputs recieved, calculating values");
		//calculate Total
		double total = userNum1 + userNum2 + userNum3 + userNum4 + userNum5;
		//calculate average
		double average = total / userInputs;
		//calculate maximum
		//find highest of first 2 numbers
		double max = Math.max(userNum1,userNum2);
		//determine if the highest of the 3rd and 4th number are higher
		if (max < Math.max(userNum3, userNum4))	{
			max = Math.max(userNum3, userNum4);
		}
		//determine if the 5th number is higher than either highest number
		if (Math.max(userNum1, userNum2) < userNum5 || Math.max(userNum3,userNum4) < userNum5)	{
			max = userNum5;
		}
		//calculate minimum
		//find the lowest of the first 2 numbers
		double min = Math.min(userNum1, userNum2);
		//determine if the lowest number of the 3rd and 4th number are lower
		if (min > Math.min(userNum3, userNum4))	{
			min = Math.min(userNum3, userNum4);
		}
		//determine if the 5th number is lower than either lowest number
		if (Math.min(userNum1, userNum2) > userNum5 || Math.min(userNum3,userNum4) > userNum5)	{
			min = userNum5;
		}
		//calculate interest on total
		double interest = total * 0.2;
		//Format and print all numbers
		System.out.println("Total: " + total);
		System.out.println("Average: " + average);
		System.out.println("Maximum: " + max);
		System.out.println("Minimum: " + min);
		System.out.println("Interest earned on total: ");
		//use a for loop to calculate the interest of the total over 5 years at 20% and print
		int i;
		for (i = 1; i < 6;i = i + 1)	{
			System.out.println("Year " + i + ": " + interest);
			total = interest + total;
			interest = (total + interest) * 0.2;
			
		}
		
	}

}
