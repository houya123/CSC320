import java.util.Scanner;
import java.util.ArrayList;
public class GetWeeklyTemps {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//Create the array lists for the days of the week
		ArrayList<String> day = new ArrayList<String>();
		day.add("Monday");
		day.add("Tuesday");
		day.add("Wednesday");
		day.add("Thursday");
		day.add("Friday");
		day.add("Saturday");
		day.add("Sunday");
		
		//Create the array list for the average temperatures
		ArrayList<Double> avrgTemp = new ArrayList<Double>();
		avrgTemp.add(70.4);
		avrgTemp.add(72.5);
		avrgTemp.add(75.8);
		avrgTemp.add(77.9);
		avrgTemp.add(73.1);
		avrgTemp.add(74.3);
		avrgTemp.add(72.4);
		
		/*	Because the assignment asked for user input at the end i assumed that we were to put in predetermined numbers in the array.
			If that is incorrect, i will include commented out code for getting the array input here. Also, i would move variables to be initialized
			sooner if this was being used, such as i, theDay and userInput
			
		 	for (i = 0; i > 7; i++)	{
		 		theDay = day.get(i);
		 		//Ask for user input, request as decimal number so that .add will function into the arraylist double
		 		System.out.println("Please enter " + theDay + "'s temperature as a decimal number");
		 		userInput = scanner.nextDouble();
		 		avrgTemp.add(userInput);
		 	}
		 */
		
		//Additional variables for loops
		String userInput;
		int i;
		String theDay;
		double theTemp;
		double theAvrgTemp;
		
		//Error checking variable for loop
		boolean loopUsed = false;
		
		//Get the average weekly temperature
		double weekAvrg = 0;
		double weekSum = 0;
		//i < 7 because there are 7 days in a week, otherwise i would use .size();
		for (i = 0; i < 7; i++)		{
			weekSum = weekSum + avrgTemp.get(i);
		}
		weekAvrg = weekSum / 7;
		
		//variable to stop loop on input
		boolean stopProgram = false;
				
		//Start user input loop
		//All if statements will have an or condition to make sure the user did not capitalize the input (For example, Week vs week)
		while (stopProgram == false)	{
			//prompt user input
			System.out.println("To get the temperature for a day, please enter a day Monday-Sunday.");
			System.out.println("To get the average temperature for the week, please enter week");
			System.out.println("To exit the program, please enter exit");
			//Receive user input string
			userInput = scanner.next();
			
			//Extra line for readability
			System.out.println();
			
			//Check if any day of the week was entered and output
			for (i = 0; i < 7; i++)		{
				theDay = day.get(i);
				theTemp = avrgTemp.get(i);
				if (userInput.equals(theDay))	{
					System.out.println(theDay + "'s Temperature: " + theTemp);
					loopUsed = true;
				}
				
			}
			//check if week was entered, but also Week since the days are capitalized
			if (userInput.equals("week") || userInput.equals("Week"))	{
				for (i = 0;i < 7; i++)	{
					theDay = day.get(i);
					theAvrgTemp = avrgTemp.get(i);
					System.out.println(theDay + ": " + theAvrgTemp);
				}
				System.out.println("The weekly average is: " + weekAvrg);
				loopUsed = true;
			}
			//Exit loop condition, check if they capitalized it as well, or entered stop instead, as it could be common
			if (userInput.equals("exit") || userInput.equals("Exit") || userInput.equals("stop") || userInput.equals("Stop"))	{
				System.out.println("Program stopped");
			stopProgram = true;
			loopUsed = true;
			}
			//Detect if no proper input was received and list all valid inputs
			if (loopUsed == false)	{
				System.out.println("Invalid input, try again and please enter one of the following:");
				System.out.println("Monday");
				System.out.println("Tueseday");
				System.out.println("Wednesday");
				System.out.println("Thursday");
				System.out.println("Friday");
				System.out.println("Saturday");
				System.out.println("Sunday");
				System.out.println("week");
				System.out.println("exit");
			}
			//Extra line for readability
			System.out.println();
		}

	}

}
