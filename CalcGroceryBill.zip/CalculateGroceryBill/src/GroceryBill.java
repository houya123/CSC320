import java.util.Scanner;

public class GroceryBill {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		double couponDiscount;
		double billOne;
		double billTwo;
		double billThree;
		double billFour;
		
		//prompt user for discount amount
		System.out.println("Please enter the coupon amount in decimal form. For example, 10% = 0.10");
		couponDiscount = scanner.nextDouble();
		//look for unexpected discount values
		if (couponDiscount > 1 )	{
			couponDiscount = 0.1;
			System.out.println("Discount greater than 100%, discount amount set to 10%");
			System.out.println();
		}
		if (couponDiscount <= 0)	{
			couponDiscount = 0.1;
			System.out.println("Discount less than or equal to 0%, discount amount set to 10%");
			System.out.println();
		}
		
		//prompt user for monthly grocery bills
		System.out.println("Please enter the first month's grocery bill in decimal form");
		billOne = scanner.nextDouble();
		
		System.out.println("Please enter the second month's grocery bill in decimal form");
		billTwo = scanner.nextDouble();
		
		System.out.println("Please enter the third month's grocery bill in decimal form");
		billThree = scanner.nextDouble();
		
		System.out.println("Please enter the fourth month's grocery bill in decimal form");
		billFour = scanner.nextDouble();
		
		//Calculate total for the month
		double monthlyTotal = billOne + billTwo + billThree + billFour;
		
		//Calculate weekly average
		double weeklyAverage = monthlyTotal / 4;
		
		//Calculate discounted weekly values
		double discountedOne = billOne - (billOne * couponDiscount);
		double discountedTwo = billTwo - (billTwo * couponDiscount);
		double discountedThree = billThree - (billThree * couponDiscount);
		double discountedFour= billThree - (billThree * couponDiscount);
		
		//Calculate discounted monthly total
		double discountedMonthlyTotal = discountedOne + discountedTwo + discountedThree + discountedFour;
		
		//Calculate discounted weekly average
		double discountedWeeklyAverage = discountedMonthlyTotal / 4;
		
		//print out all results to user
		System.out.println("Monthly Total before discount: " + monthlyTotal);
		System.out.println("Weekly Average before discount: " + weeklyAverage);
		System.out.println("Discounted monthly total: " + discountedMonthlyTotal);
		System.out.println("Discounted weekly average: " + discountedWeeklyAverage );
	
	}

}
