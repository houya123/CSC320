
public class ListRestaurantName {

	public static void main(String[] args) {
		//Create variables to store restaurant information (not necessary, but makes it more modular)
		String restaurantName = "SMOKE. Woodfire Grill";
		String businessAddress = "1542 E 15th St";
		String city = "Tulsa";
		String USstate = "OK";
		int zipCode = 74120;
		//print out information in a clear and readable way... extra space added to make it look like an address in formatting
		System.out.println("Restaurant name:             " + restaurantName);
		System.out.println("Business address:            " + businessAddress);
		System.out.println("City, State, and Zip code:   " + city + ", " + USstate + ", " + zipCode);
		

	}

}
