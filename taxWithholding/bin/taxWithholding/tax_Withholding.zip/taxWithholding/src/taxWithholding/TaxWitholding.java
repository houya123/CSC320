package taxWithholding;
import java.util.Scanner;
public class TaxWitholding {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		double pay = 0.00;
		int bracket = 0;
		double taxAmount = 0.00;
		//ask for pay amount
		System.out.println("Please enter your weekly gross pay, do not include a dollar sign.");
		pay = scanner.nextDouble();
		//calculate which tax bracket the pay belongs in
		if (pay < 500 && pay >= 0)   {
			bracket = 1;
		}
		else if (pay >= 500 && pay < 1500)	{
			bracket = 2;
		}
		else if (pay >= 1500 && pay < 2500)	{
			bracket = 3;
		}
		else if (pay > 2500)	{
			bracket = 4;
		}
		else {
			System.out.println("Invalid input, please try again");
		}
		//use bracket and pay amount to calculate the withholding
		switch (bracket)	{
			case 1:
				taxAmount = pay * 0.1;
				break;
			case 2:
				taxAmount = pay * 0.15;
				break;
			case 3:
				taxAmount = pay * 0.2;
				break;
			case 4:
				taxAmount = pay * 0.3;
				break;
		}
		//Output the results in a readable form
		// FIX LATER - MAKE IT OUTPUT AS 2 DECIMALS
		System.out.print("if you are making $" + pay + " a week, $" + taxAmount + " will be withheld every week in taxes.");
	}

}
